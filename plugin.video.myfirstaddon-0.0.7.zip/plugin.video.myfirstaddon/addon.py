import xbmcaddon
import xbmcgui
import xbmcplugin

# Get the addon handle and instance
addon_handle = int(sys.argv[1])
addon = xbmcaddon.Addon()

def main_menu():
    """Display a list of configured RTSP or MJPEG streams with thumbnails"""
    # List to store valid streams
    streams = []

    # Read settings for up to 16 streams
    try:
        for i in range(1, 17):
            name = addon.getSetting(f"stream{i}_name").strip()
            url = addon.getSetting(f"stream{i}_url").strip()
            thumb = addon.getSetting(f"stream{i}_thumb").strip()
            if url:  # Only include streams with non-empty URLs
                streams.append({
                    "name": name or f"Stream {i}",
                    "url": url,
                    "thumb": thumb if thumb else None
                })
    except Exception as e:
        xbmcgui.Dialog().ok("Error", f"Failed to load settings: {str(e)}")
        return

    if not streams:
        # Show error if no valid URLs are configured
        xbmcgui.Dialog().ok("Error", "Please configure at least one stream URL in the addon settings.")
        return

    # Create a list item for each stream
    for stream in streams:
        li = xbmcgui.ListItem(label=stream["name"])
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": stream["name"], "mediatype": "video"})
        if stream["thumb"]:
            li.setArt({"thumb": stream["thumb"], "icon": stream["thumb"]})
        xbmcplugin.addDirectoryItem(
            handle=addon_handle,
            url=stream["url"],
            listitem=li,
            isFolder=False
        )

    # End the directory
    xbmcplugin.endOfDirectory(addon_handle)

if __name__ == "__main__":
    main_menu()